"UPmidzuno" <-
function(pik,eps=1e-6) 1-UPtille(1-pik,eps)

